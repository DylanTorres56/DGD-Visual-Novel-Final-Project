TrueTypeFont: Republica Minor 2.0 (Regular, Bold, Italic, and Bold Italic)
Dennis Ludlow 2016 all rights reserved
Sharkshock Productions
dennis@sharkshock.net


Republica Minor gets an update and a little bit of a facelift in this revision. Gone are the round punctuation marks while the ampersand, capital M, and R receive slight augmentations among others. This font has been a popular choice for a strong looking logo, TV shows, or video games.  Kerning
 is updated for classes now and support for Macedonian/Serbain italics added via contextual alternates. Like the original this display font features very tight spacing and slight overlap is expected with European accents and diacritics. The complete version contains basic and extended latin, 
full punctuation, scientific marks, mathematical symbols, kerning, Eastern European accents, Cyrillic characters (with proper italics), and Greek characters. Regular is included for free while Italic, Bold, and Bold Italic are available for $15 or with purchase of end user license agreement (EULA). 

This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to discuss an end user license.
If you've previously licensed Padaloma or Republica Minor you're grandfathered into this version. Thank you! I also design custom fonts for businesses, logos, and many other things. If you'd like to 
leave me a donation you can use the same address via paypal. Your generosity will be most appreciated!

tags: sans, san serif, wide, block, thick, publishing, headlines, news, title, books, magazine, logo, show, tv, kids, children, game, italic, Greek, Russian, Cyrillic, latin, alphabet, diacritics


visit www.sharkshock.net for more and take a bite out of BORING design!

